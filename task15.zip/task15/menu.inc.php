              <div class="d-none d-sm-none d-md-none d-lg-block col-lg-7 offset-lg-5 menu">
                        <ul class="nav_menu">
                            <li class="menu__list"><a href="#" class="menu__link"> ГЛАВНАЯ</a></li>
                            <li class="menu__list"><a href="#" class="menu__link"> ОБ АВТОРЕ</a></li>
                            <li class="menu__list"><a href="#" class="menu__link"> РАБОТЫ</a></li>
                            <li class="menu__list"><a href="#" class="menu__link"> ПРОЦЕСС</a></li>
                            <li class="menu__list"><a href="#" class="menu__link"> КОНТАКТЫ</a></li>
                        </ul>
                    </div>