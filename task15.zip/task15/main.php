<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой сайт</title>
    <link rel="icon" href="img/laptop.png">
    <meta property="og:image" content="img/@1x/preview.jpg">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">
	<!-- fancyBox CSS -->
<link href="fancybox-master/dist/jquery.fancybox.min.css" rel="stylesheet">

<!-- fancyBox JS -->
<script src="fancybox-master/dist/jquery.fancybox.min.js"></script>
 
</head>

<body>
 
    <section class="section section_first">
        <div class="container">
            <div class="row row_1">
               <div class="col-12 logo_menu">
                <div class="col-lg-1 logo"> <img src="img/WD.png" alt="Bootstrap"> </div>
				 <?php include 'menu.inc.php' ?>	
                </div>  
            </div>
           <div class="row row_2">  
                <div class="col-lg-12 write_me">
                    <div class="col-lg-4 offset-lg-1 img"> <img src="img/Frame.png" alt="Bootstrap"> </div> 
                    <div class="col-lg-6 offset-lg-2 present">
                        <h1>Дизайн и верстка</h1>
                        <p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. 
                            Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.</p>
                            <button class="button button_write">Написать мне</button>
                    </div>
                </div>    
            </div> 
        </div>
    </section>
	
	 <section class="section section_second">
        <div class="container">
            <div class="row row_3">
                <div class="col-12 about_me">
                    <div class="col-lg-2 offset-lg-6 h2_text"> <h2> Обо мне </h2> </div>
                    <div class="col-lg-6 offset-lg-4 p_text"><p> <p> Меня зовут 
                    <?php echo $name, ' ', $surname . '<br>'; 
                          echo 'город', ' ', $city; ?>                                      
                     
           <br>
                    Мне
                    <?php  echo $age;   ?>          
                    лет </p></p></div>
                </div>
            </div>
        </div>
    </section>

    <section class="section section_third">
        <div class="container">
            <div class="row row_4">
                <div class="col-11 offset-1 gallery embed-responsive">   
                        <img class="col-1 img_gallery" src="img/project.png" alt="Bootstrap"> <p class="col-1 p_project"> <?php   echo $a?> </p>
                        <img class="col-1 img_gallery" src="img/project.png" alt="Bootstrap"> <p class="col-1 p_project"><?php   echo $b?></p>
                        <img class="col-1 img_gallery" src="img/project.png" alt="Bootstrap"> <p class="col-1 p_project"><?php   echo $c?></p>
                        <img class="col-1 img_gallery" src="img/project.png" alt="Bootstrap"> <p class="col-1 p_project"><?php   echo $d?></p>
                        <img class="col-1 img_gallery" src="img/project.png" alt="Bootstrap"> <p class="col-1 p_project"><?php   echo $e?></p>
                                     
                </div>
            </div>
        </div>
    </section>
	
	
	
	
	    <section class="section section_fourth">
        <div class="container">

     <div class="row row_2">  
                <div class="col-lg-12 skill">
              
                    <div class="col-lg-6 offset-lg-2 present">
                        <h1>Мои навыки</h1>
                        <p>
						<div class="indikator">
<span>Adobe Photoshop</span>
</div>
						</p>
		                        <p>
						<div class="indikator">
<span>Adobe Photoshop</span>
</div>
						</p>                        <p>
						<div class="indikator">
<span>Adobe Photoshop</span>
</div>
						</p>				
						
						
						
						<a href="#call">
                            <button class="button button_write">Написать мне</button></a>
                    </div>
					   <div class="col-lg-4 offset-lg-1 img"> <img src="img/Rectangle 3.png" alt="Bootstrap"> </div>
					    
                </div>    
            </div> 
        </div>   
    </section>
	
	
	
	
	
	
	
	

    <section class="section section_fifth">
        <div class="container">
            <div class="row row_6">
                <div class="col-12 work">
                    <div class="col-lg-3 offset-lg-6 h2_text"> <h2> Как я работаю </h2> </div>
                    <div class="col-lg-6 offset-lg-4 p_text"><p>Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. 
                        Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.</p></div>
                </div>
            </div>
            <div class="row row_7">
                <div class="col-12 video">
                    <div class="col-lg-12">
                        <iframe width="1100px" height="600px" src="https://www.youtube.com/embed/gnVYWcavOXs" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>   
    </section>
	
	
	
	
	
	
    <section class="section section_six">
        
		
		
		<div class="container">

    <div class="row">
        <div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
        <div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
		       <div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
		       <div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
		  </div>
		
		<div class="row">
           <div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>       
		
		<div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
		
		
			<div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
			<div class="col-lg-3 col-md-4 col-6 thumb">
            <a data-fancybox="gallery" href="img/Rectangle 7.png">
                <img class="img-fluid" src="img/Rectangle 7.png" alt="...">
            </a>
        </div>
		
		
    </div>
</div>
		
		
		
		
		
		
		
		
		
    </section>
	
	
	
	    <section class="section section_seven">
	
	
	<div class="row"><div class="col"></div>
    <div class="col"><img class="img-fluid" src="img/Rectangle 9.3.png" ></div>
     <div class="col"><img class="img-fluid" src="img/Rectangle 9.3.png" ></div>
     <div class="col"><img class="img-fluid" src="img/Rectangle 9.3.png" ></div>
     <div class="col"><img class="img-fluid" src="img/Rectangle 9.3.png" ></div>
  <div class="col"></div>
</div>
	
	 </section>





	
	    <section class="section section_eight">
	
<div class="container">
<div class="row">

<div class="col-md-6">
   <h4>Хотите веб-сайт?</h4>
   <a name="call"></a>
   <p> Lorem Ipsum - это текст-"рыба", часто используемый в печати и вэб-дизайне. Lorem Ipsum является стандартной "рыбой" для текстов на латинице с начала XVI века.</p>
   <form action="./mail.php" method="post">
<div class="form-group inline">
 
   <input type="name" name="name" class="form-control" id="name" placeholder="Ваше имя:">
</div>
<div class="form-group inline">
   <input type="email" name="email" class="form-control" id="email1" placeholder="Ваш e-mail">
</div>

<div class="form-group">

   <textarea class="form-control" name="message" rows="6" placeholder="Сообщение"></textarea>
</div>
   <button type="submit" class="btn">Отправить</button>
</form>







</div>
	</div>
	 </section>




<div class="footer">


<div class = "footer-menu"> 
        <div class = "footer-container"> 
       <p> Иванов Иван <br>(с) 2018. Все права защищены. </p> 
	
        <p class =" copy-right "><img class="img-fluid" src="img/vk-social-network-logo.png" ><img class="img-fluid" src="img/vk-social-network-logo.png" ><img class="img-fluid" src="img/vk-social-network-logo.png" ></p> 
        <div class = "clearfix"> </ div> 
        </ div> 
    </ div>




</div>






	</div>
	

   
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>


</body>